﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using _20._102k_15_Authorization.Entities;

namespace _20._102k_15_Authorization
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnLogIn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string login = txtboxLogin.Text; // Извлечение данных из полей ввода
                string password = pswrdbox.Password;

                User user = new User(); // Создание экземпляра пользователья

                user = Entities.Entities.GetContext().User.Where(p => p.Login == login && p.Password == password).FirstOrDefault();
                int userCount = Entities.Entities.GetContext().User.Where(p => p.Login == login && p.Password == password).Count();

                if (userCount > 0) // Вывод сообщения об успешной авторизации при наличии записи, имеющей введёный логин и пароль
                {
                    MessageBox.Show("Успешная авторизация\nВход под учётной записью " + user.FirstName.ToString() + " \"" + user.Role.RoleName.ToString() + "\"");
                }
                else
                {
                    MessageBox.Show("Неверный логин или пароль!");
                }
            }
            catch (Exception exception) // Обработка исключений
            {
                MessageBox.Show("Ошибка! " + exception);
            }
        }
    }
}
